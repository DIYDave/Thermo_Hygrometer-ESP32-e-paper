
// Läuft gut mit Sensor und Display und Batterie messung
// Geflackere für Display Refresh dauert 23 Sek. dabei fliessen 22mA.
// Im DeepSleep immer noch ca. 0.5mA wenn VCC sensor und display aus ca. 46uA
// - Batt Spannungsmessung 2 x 220kOhm ca. 10 uA Strom
// - Sleep
// - WiFi   
// - MQTT
// - Zeitserver

// ToDo:
// Ev. Aufruf Wifi close wenn IP bekannt und erst nach WiFi close rest ausführen

/*  Die D.. funktionieren in der Regel nicht GPIO verwenden
GPIO    D..    Color        Signal
 2      D0/A0           Batterie Spannungsteiler
 3      D1/A1   lila    Display BUSY
 4      D2/A2   white   Display DC
 5      D3      blue    Display CS 
 6      D4              Sensor SDA
 7      D5              Sensor SCL
 8      D8      green   Display SCL(SCK)
 9      D9      
 10     D10     yellow  Display SDA(MOSI)
 20     D7              GND geschaltet für Display und Sensor
 21     D6      orange  Display RES
*/

#include <main.h>

// Pixel 128 x 296  0,0 ist oben links

void setup(){
  Serial.begin(115200);
  pinMode(BATTVOLT, INPUT);
  pinMode(POWERSWITCH, OUTPUT);    // GND für Sensor und Display
  digitalWrite(POWERSWITCH, LOW);
  esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP * uS_TO_S_FACTOR);
  flash.begin("my-app", false);       // Namespace, false for RW-mode
    AP = flash.getInt("lastSSID", 0);
    noWiFi = flash.getBool("noWiFi");
  flash.end();
  AHT.begin(SDA,SCL);
  display.init(115200,true,5,false);
// Various handler     
  WiFi.onEvent(onWifiDisconnect, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_DISCONNECTED);  
  WiFi.onEvent(onWifiIP, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_GOT_IP);   

// If I couldn't connect last time, I go to sleep and try again when I wake up
  if (noWiFi){
    flash.begin("my-app", false);
    flash.putBool("noWiFi", 0);
    flash.putInt("lastSSID", 0);
    flash.end();
    goToSleep();
  }
  connectToWifi();        // Tray to connect without waiting here
  ++bootCount;
}

void connectToWifi() {
  WiFi.mode(WIFI_STA);
  //Serial.println("Connecting to Wi-Fi...");
      //if (!WiFi.config(IP, GATEWAY, SUBNET, primaryDNS, secondaryDNS)){   // Static IP
      //    Serial.println("Konfig Fehler");
      //};
  //Serial.print("Versuche mit: "); Serial.println(AccessPoint[AP][0]);
  WiFi.begin(AccessPoint[AP][0], AccessPoint[AP][1]); // SSID , password
}

void onWifiIP(WiFiEvent_t event, WiFiEventInfo_t info) {
  if (!IPok){     // Verhindert weiteren Start wenn IP bei Verbindung mit Broker noch einmal gesendet wird. )
    //Serial.print("Connected to Wi-Fi: ");
    //Serial.println(WiFi.SSID()); 
    //Serial.println(WiFi.localIP());
    flash.begin("my-app", false);
      if ((flash.getInt("lastSSID",4) !=AP)||(flash.getBool("noWiFi") != noWiFi)){  // write to flash only if changed
        flash.putInt("lastSSID", AP);
        flash.putBool("noWiFi", 0);
      };
    flash.end();
    IPok = true;
    myIP = WiFi.localIP();    // copy local for Display
    mySSID = WiFi.SSID();     // copy local for Display
    initTime("CET-1CEST,M3.5.0,M10.5.0/3");   // Set for Zurich
    connectToMqtt();
  }
}

void initTime(String timezone){
    struct tm timeinfo;
    configTime(0, 0, "ntp.metas.ch");    // First connect to NTP server, with 0 TZ offset

    //Serial.println("  Got the time from NTP");
    setenv("TZ",timezone.c_str(),1);  //  Now adjust the TZ.  Clock settings are adjusted to show the new local time
    tzset();
    if(!getLocalTime(&timeinfo)){
      Serial.println("  Failed to obtain time");
      return;
    }
	strftime (sTime,sizeof (sTime),"%d.%m.%Y %R",&timeinfo);  // String aus Time  https://cplusplus.com/reference/ctime/strftime/?kw=strftime
}


void connectToMqtt() {
  //Serial.println("Connecting to MQTT...");
  MQTTclient.begin(MQTT_HOST, wifi);
  while (!MQTTclient.connect("ESP32C3")) {    // ID
    //Serial.print(".");
    delay(100);
  }
    readBattery();
    readSensor();
}

void readBattery(){
  uint32_t Vbatt = 0;
  for(int i = 0; i < 10; i++) {
    Vbatt = Vbatt + analogReadMilliVolts(BATTVOLT);   // ADC with correction   
    delay(10);
  }
  fVbatt = 2.024 * Vbatt / 10.0 / 1000.0;     // 2.024 = Offset durch Toleranz Spannungsteiler
}

void readSensor(){
  int ret = AHT.getSensor(&humi, &temp);
  if(ret) {    // GET DATA OK
    humi = humi * 100;
    mqttPublish();
  }
}

void mqttPublish(){       // Publish MQTT message
  char payload[30];
  sprintf(payload, "%d,%.1f,%.0f,%.2f", bootCount, temp, humi, fVbatt); 
  if (MQTTclient.publish(LOACTION, payload ,false,0)){    // Topic,QoS,Retain,Payload,
    allesBono = true; 
    // Serial.println("Alles Bono");
    disconnect();
  }  
}

void disconnect(){
  MQTTclient.disconnect();
  delay(100);
  WiFi.disconnect();;
}

void onWifiDisconnect(WiFiEvent_t event, WiFiEventInfo_t info) {
  WiFi.mode(WIFI_OFF);
  WiFi.mode(WIFI_STA);
  //Serial.println("Disconnected from Wi-Fi.");
  AP ++;
  if (!allesBono){
    if (AP > MAX_AP-1) {      // Keine Verbindung mit einem AP in der liste
      flash.begin("my-app", false);
      flash.putBool("noWiFi", 1);
      noWiFi = flash.getBool("noWiFi");
      flash.putInt("lastSSID", 0);
      flash.end();
      ESP.restart();
    }else{
      wifiReconnectTimer.once(2, connectToWifi);
    }
  }else{
    createDisplay();
  }
}

void createDisplay(){
  display.setRotation(0);                       // Hochkannt Stecker oben
  display.setFont(&FreeMonoBold12pt7b);          
  display.setTextColor(GxEPD_BLACK);
  String battdisp = String(fVbatt,2) + "V";
  String tempdisp = String(temp,1);             // Float zu String 1 Dezimal
  String humidisp = String(humi,0) + "%";   	// Float zu String 0 Dezimal
  int iTemp=10*(temp);                          // ° * 10 zu Position roter Balken
  int y = map(iTemp, 170, 300, -12, -234);      // Y Position Balken und Anzeige
  display.setFullWindow();
  display.firstPage();
  do
  {
    display.fillScreen(GxEPD_WHITE);
    display.setCursor(54, 256 + 6 + y);   
    display.print(tempdisp);
    display.setCursor(70, 256 + 28 + y);    
    display.print(humidisp);
    display.drawCircle(113,250 + y, 3, GxEPD_BLACK); // Grad Symbol
    display.drawCircle(113,250 + y, 2, GxEPD_BLACK); // Grad Symbol doppelt
    display.fillCircle(35,268,12,GxEPD_RED);        // Rote Kugel  
    display.drawCircle(35,268,14,GxEPD_BLACK);      // Ring um Kugel
    display.fillRect(32,256,8,y,GxEPD_RED);         // Rote, vertikale Anzeige Temp  -234
    display.drawLine(30,256,30,18, GxEPD_BLACK);    // Linie um Balken links
    display.drawLine(41,256,41,18, GxEPD_BLACK);    // Linie um Balken rechts
    display.drawCircleHelper(36,18,6,1,GxEPD_BLACK);  // Bögli oben links
    display.drawCircleHelper(35,18,6,2,GxEPD_BLACK);  // Bögli oben rechts
    display.setFont(&Font5x7Fixed);  
    for(int16_t i = 0; i < 14; i++) {
      display.drawLine(17, 242-(i*17), 25, 242-(i*17), GxEPD_BLACK);  // Skala links
      display.setCursor(4, 246-(i*17));    // Skala Nummer Position
      int16_t num = 17+(i*1);             // Skala Werte
      String TempScala = String(num);
      display.print(TempScala);  
    } 
    display.setCursor(2, 294);
    //display.print(bootCount);
    display.print(battdisp);
    //display.setCursor(25, 294);
    //display.print(mySSID); 
    display.setCursor(46, 294);
    String sDateTime(sTime);
    //display.print(myIP);
    display.print(sDateTime); 
  }
  while (display.nextPage());
  display.hibernate();
  goToSleep();
}


void goToSleep(){
  digitalWrite(POWERSWITCH, HIGH);
  esp_deep_sleep_start();
}

void loop(){
  if (millis() > 40000){       //  timeout   
    goToSleep();
  }
}

