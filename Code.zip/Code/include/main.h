#include <Arduino.h>
#include <Time.h>
#include <WiFi.h>
#include <Wire.h>
#include <MQTT.h>                  // https://github.com/256dpi/arduino-mqtt
#include <Ticker.h>               // https://github.com/esp8266/Arduino/tree/master/libraries/Ticker
#include <Preferences.h>          // Flash handling
#include "AHT20.h"                // Angepasste Version mit vorgabe der pin bei "begin". Original:  https://github.com/Seeed-Studio/Seeed_Arduino_AHT20
#include <GxEPD2_3C.h>                      // https://github.com/ZinggJM/GxEPD2/tree/master
#include <Fonts/FreeMonoBold9pt7b.h>        // https://github.com/adafruit/Adafruit-GFX-Library/tree/master
#include <Fonts/FreeMonoBold12pt7b.h>       //https://learn.adafruit.com/adafruit-gfx-graphics-library/using-fonts
#include <Fonts/Picopixel.h>
#include <GFX_fonts/Font5x7Fixed.h>
#define ENABLE_GxEPD2_GFX 0

// Constants
  #define SDA 6               // i2c bus pins 
  #define SCL 7               // i2c bus pins  
  #define POWERSWITCH 20      // GND for Display and Sensor
  #define BATTVOLT 2          // Analog IN 1 Battery Voltage 
  #define uS_TO_S_FACTOR 1000000  /* Conversion factor for micro seconds to seconds */
  #define TIME_TO_SLEEP  900        /* Time ESP32 will stay in sleep mode (in seconds) */

  char LOACTION[10] = "Room2";    // MQTT Topic

AHT20 AHT;
Ticker mqttReconnectTimer;
Ticker wifiReconnectTimer;
Preferences flash;
WiFiClient wifi;
MQTTClient MQTTclient;

// WeAct ePaper 2.9" Rot, SW, WS. Vermutlich identisch mit WaveShare
GxEPD2_3C<GxEPD2_290_C90c, GxEPD2_290_C90c::HEIGHT> display(GxEPD2_290_C90c(/*CS=5*/ 5, /*DC=*/ 4, /*RES=*/ 21, /*BUSY=*/ 3)); // GDEM029C90 128x296, SSD1680

// Ethernet Settings
  const int MAX_AP = 3;       // Try to connect to the following AP's
  const char* AccessPoint[MAX_AP][2] = { 
    {"SSID1",  "password"},
    {"SSID2",  "password"},
    {"SSID3",  "password"}
  };

  IPAddress IP(192,168,0,34);       // Static IP adress for faster connection
  IPAddress GATEWAY(192,168,0,1);
  IPAddress SUBNET(255,255,255,0);
  IPAddress primaryDNS(8, 8, 8, 8); 
  IPAddress secondaryDNS(8, 8, 4, 4);
  const char MQTT_HOST[] = "192.168.0.10" ; ;  //const char MQTT_HOST "test.mosquitto.org";
  #define MQTT_PORT 1883

// Global Labels
  int AP;             // In Flash        // for different wifi SSID's
  bool noWiFi;        // In Flash
  bool allesBono = false;
  bool IPok,second;
  float humi, temp;
  unsigned long lastTime, period = 1000;
  float fVbatt;
  IPAddress myIP; String mySSID;
  char sTime[30];
  RTC_DATA_ATTR int bootCount = 0;  // Wird im RTC 8kB SRAM gespeichert (Wird gelöscht bei Reset)

// Function declaration
  void onWifiIP(WiFiEvent_t, WiFiEventInfo_t); 
  void onWifiConnect(WiFiEvent_t, WiFiEventInfo_t);
  void onWifiDisconnect(WiFiEvent_t, WiFiEventInfo_t);
  void initTime(String timezone);
  void mqttPublish();
  void connectToMqtt();
  void disconnect();
  void connectToWifi();
  void connectToMqtt();
  void connectToWifi();
  void goToSleep();
  void readSensor();
  void createDisplay();
  void readBattery();
